#ifndef PWM_H
#define PWM_H

void initPWMTimer3();
void initPWMTimer4();
void changeDutyCycle(unsigned int num);

#endif