#ifndef SSD_H
#define SSD_H

void seven_segment_init();
void display(int num);
void countdown();

#endif