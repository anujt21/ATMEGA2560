#ifndef ADC_H
#define ADC_H


void initADC();
unsigned int read_adc();

#endif