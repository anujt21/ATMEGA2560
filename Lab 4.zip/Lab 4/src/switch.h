// Description: Function prototypes for switch.cpp
//----------------------------------------------------------------------//

#ifndef SWITCH_H
#define SWITCH_H

void initSwitchPD0();
void enableSwitch();
void disableSwitch();

#endif
